//using Database;
using NUnit.Framework;
using System;

namespace Tests
{
    public class DatabaseTests
    {
        [SetUp]
        public void Setup()
        {
        }
        [Test]
        public void ConstructorShouldBeInitializeWith16Elements()
        {
            var array = new int[16];
            var database = new Database(array);

            int expectedCount = 16;
            int actualCount = database.Count;

            Assert.AreEqual(expectedCount, actualCount);
        }
        [Test]
        public void ArraySizeLengthTestIfNotValid()
        {
            int arrayLenght = 17;
            Assert.Throws<InvalidOperationException>(() => new Database(new int[arrayLenght]));
        }
        [Test]
        public void NotValidAddOperationToArray()
        {
            var arrayLenght = 16;
            var array = new int[arrayLenght];
            var database = new Database(array);

            Assert.Throws<InvalidOperationException>(() => database.Add(5));
        }
        [TestCase(1)]
        [TestCase(-1)]
        [TestCase(100000)]
        public void ValidOperataionAddToArray(int elementToAdd)
        {
            var arrayLenght = 10;
            var array = new int[arrayLenght];
            var database = new Database(array);

            database.Add(elementToAdd);
            Assert.IsTrue(database.Count == 11);
        }

        [Test]
        public void RemoveElementFromEmptyArray()
        {
            var database = new Database();

            Assert.Throws<InvalidOperationException>(() => database.Remove());
        }
        [Test]
        public void ValidRemoveOperation()
        {
            //add only one element and then remove it
            var database = new Database(5);

            database.Remove();
            Assert.AreEqual(database.Count, 0);
        }
        [Test]
        public void ShouldRemoveCorrectlyAndDecreaseCount()
        {
            int[] array = { 1, 2, 3 };
            var database = new Database(array);
            database.Remove();

            int expected = 2;
            int actualCount = database.Count;

            Assert.AreEqual(expected, actualCount);
        }
            

        [Test]
        public void TestConstructorTakingOnlyIntegers()
        {
            var array = new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 10, 11, 12, 13, 14, 15 };
            var database = new Database(array);
            //Assert.IsTrue(()=>new Database(array))
        }

        [Test]
        public void TestIfFetchReturnArray()
        {
            int[] array = new int[] { 1, 2, 3, 4, 5 };

            Database database = new Database(array);
            database.Add(6);

            int expectedResult = 6;
            int result = database.Fetch()[5];

            Assert.AreEqual(expectedResult, result);
        }

        [Test]
        public void FetchMethodShouldReturnAllElementsAsArray()
        {
            int[] array = { 1, 5, 2, 4, 5 };
            var database = new Database(array);

            int[] expectedValues = { 1, 5, 2, 4, 5 };
            int[] actualValues = database.Fetch();

            CollectionAssert.AreEqual(expectedValues, actualValues);
        }
    }
}