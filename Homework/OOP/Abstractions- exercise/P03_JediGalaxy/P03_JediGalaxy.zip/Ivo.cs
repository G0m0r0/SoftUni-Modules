﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_JediGalaxy
{
    public class Ivo
    {
        public int X { get; set; }
        public int Y { get; set; }

        public Ivo(int x,int y)
        {
            this.X = x;
            this.Y = y;
        }
    }
}
