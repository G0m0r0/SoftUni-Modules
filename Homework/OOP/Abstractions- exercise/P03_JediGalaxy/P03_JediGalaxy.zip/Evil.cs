﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_JediGalaxy
{
    public class Evil
    {
        public int X { get; set; }
        public int Y { get; set; }

        public Evil(int x, int y)
        {
            this.X = x;
            this.Y = y;
        }
    }
}
