﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    public interface IRobot:ICitizen
    {
        public string Model { get;  }

    }
}
