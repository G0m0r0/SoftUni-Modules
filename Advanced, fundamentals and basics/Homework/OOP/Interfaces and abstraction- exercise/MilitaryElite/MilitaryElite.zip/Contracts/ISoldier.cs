﻿namespace MilitaryElite.Contracts
{
    public interface ISoldier
    {
        public string FirstName { get; }
        public string LastName { get; }
        public int Id { get; }
    }
}
