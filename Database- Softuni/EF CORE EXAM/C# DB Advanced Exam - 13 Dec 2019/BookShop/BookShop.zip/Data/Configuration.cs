﻿namespace BookShop.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=BookShopExamPrep;Trusted_Connection=True";
    }
}