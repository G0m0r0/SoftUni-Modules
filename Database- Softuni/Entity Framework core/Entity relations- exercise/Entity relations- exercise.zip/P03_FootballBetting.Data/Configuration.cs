﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_FootballBetting.Data
{
    internal static class Configuration
    {
        //.gitignore 
        internal static string ConnectionString = @"Server=.;Database=FootballBettingSystem; Integrated security=true;";
    }
}
