﻿namespace P01_StudentSystem.Data
{
    internal static class Configuration
    {
        //.gitignore 
        internal static string ConnectionString = @"Server=.;Database=StudentSystem; Integrated security=true;";
    }
}
