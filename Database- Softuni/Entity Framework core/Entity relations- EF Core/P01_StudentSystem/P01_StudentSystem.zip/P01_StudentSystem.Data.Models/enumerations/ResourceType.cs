﻿
namespace P01_StudentSystem.Data.Models.enumerations
{
    public enum ResourceType
    {
        Video=0,
        Presentation=1,
        Document=2,
        Other=3
    }
}
