﻿namespace P01_StudentSystem.Data.Models.enumerations
{
    public enum ContentType
    {
        Application=0,
        Pdf=1,
        Zip=2,
    }
}
