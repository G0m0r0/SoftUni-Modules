﻿namespace P03_SalesDatabase.Common
{
    public class GlobalConstants
    {
        public const int maxLengthDescription = 250;
        public const int nameMaxLength = 50;
        public const int customerNameMaxLenght = 100;
        public const int customerEmailMaxLegth = 80;
        public const int storeNameMaxLength = 80;
    }
}
