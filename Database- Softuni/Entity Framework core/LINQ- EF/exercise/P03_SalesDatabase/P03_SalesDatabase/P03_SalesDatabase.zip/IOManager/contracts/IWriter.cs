﻿namespace P03_SalesDatabase.IOManager.contracts
{
    public interface IWriter
    {
        void WriteLine(string text);
        void Write(string text);
    }
}
