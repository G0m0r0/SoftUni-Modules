﻿namespace P03_SalesDatabase.IOManager.contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
