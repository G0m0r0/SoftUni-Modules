﻿namespace P03_SalesDatabase.Data.seeding.contracts
{
    public interface ISeeder
    {
        void Seed();
    }
}
