﻿namespace P03_SalesDatabase.Data.configuration
{
    internal static class Configuration
    {
        internal static string ConnectionString = @"Server=.;Database=SalesSystem; Integrated security=true;";
    }
}
