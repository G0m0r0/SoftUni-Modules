﻿namespace P01_HospitalDatabase.Data.Configuration
{
    internal static class Configuration
    {
        internal static string ConnectionString = "Server=.;Database=HospitalDB; Integrated security=true;";
    }
}
